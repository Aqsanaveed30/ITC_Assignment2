#include<iostream>
using namespace std;
int main()
{
    int initialbalance, pincode, enteredpin, choice, amount, balance;
    initialbalance = 1000;
    pincode = 1234; //correct pin
    do
    {
        
        cout << "BANK ACCOUNT MANAGEMENT SYSTEM" << endl;
        cout << "1. Deposit money" << endl;
        cout << "2. Withdraw money" << endl;
        cout << "3. Check balance" << endl;
        cout << "4. EXIT" << endl;
        cin >> choice;
        switch(choice)
        {
            case 1: //money deposit
            cout << "Enter amount to deposit: " ;
            cin >> amount;
            if(amount > 0)
            {
                balance = initialbalance + amount;
                cout << "Deposited amount is: " << balance << endl;
            }
            else 
            {
                cout << "Invalid amount" << endl;
            }
            break ;
            case 2:  // withdrawal of money
            cout << "Enter your pin: " << endl;
            if(enteredpin == pincode)
            {
                cout << "Enter the withdrawalamount: ";
                cin >> amount;
                if(amount > 0 && amount <= balance)
                {
                    balance -= amount;
                    cout << "Withdrawal amount is: " << amount << endl;
                }
                else 
                {
                    cout << "Invalid amount" << endl;
                }
            }
            else 
            {
                cout << "INCORRECT PIN" << endl;
            }
            break;
            case 3:  //checking the balance
            cout << "Enter your pin: ";
            cin >> enteredpin;
            if (enteredpin == pincode)
            {
                cout << "Your balance is: " << balance << endl;
            }
            else 
            {
                cout << "INCORRECT PIN " << endl;
            }
            break;
            case 4:  //exit the system 
            cout << "System exit" << endl;
            break;
            
            default:
            cout << "TRY AGAIN" << endl;
        }
    
    }
    while (choice != 4);
    
    return 0;
}