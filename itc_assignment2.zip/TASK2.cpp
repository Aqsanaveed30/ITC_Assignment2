#include <iostream>
using namespace std;
int main ()
{
    int availableBooks = 3; 
    int borrowedBooks = 0;   
    int choice;

    cout << "Library Book Borrowing System\n";
    while (true) {
        cout << "\n1. Borrow a Book\n";
        cout << "2. Return a Book\n";
        cout << "3. Exit\n";
        cout << "Enter your choice: ";
        cin >> choice;

        if (choice == 1) { 
            if (availableBooks > 0) {
                availableBooks--;
                borrowedBooks++;
                cout << "You have borrowed a book. Books left: " << availableBooks << endl;
            } else {
                cout << "Sorry, no books available.\n";
            }
        } else if (choice == 2) {  
            if (borrowedBooks > 0) {
                availableBooks++;
                borrowedBooks--;
                cout << "You have returned a book. Books left: " << availableBooks << endl;
            } else {
                cout << "You haven't borrowed any books yet.\n";
            }
        } else if (choice == 3) { 
            cout << "Exiting system. Goodbye!\n";
            break;
        } else {
            cout << "Invalid choice. Please try again.\n";
        }
    }

    return 0;