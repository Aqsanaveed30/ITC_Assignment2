#include <iostream>
using namespace std;

int main() {
    int count = 1;

    while (count <= 5) {
        int stars = 1; 

        while (stars <= count) { 
            cout << "*"; 
            stars++; 
        }

        cout << endl; 
        count++; 
    }

    return 0; 
}
